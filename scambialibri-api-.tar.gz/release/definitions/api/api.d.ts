import { Configuration } from 'core/config';
import { Db } from 'core/db';
import { Logger } from 'core/log';
import { PassportConfiguration } from 'core/passport';
import { ResponseService } from 'services/response.service';
import { RouterFactory } from 'api/router';
export declare class Api {
    private _config;
    private _logger;
    private _db;
    private _passport;
    private _route;
    private _responseService;
    private _app;
    private _server;
    constructor(_config: Configuration, _logger: Logger, _db: Db, _passport: PassportConfiguration, _route: RouterFactory, _responseService: ResponseService);
    setup(): Promise<any>;
    listen(): Promise<any>;
    close(): Promise<any>;
}
