export declare class BookController {
    getBooks(req: any, res: any, next: any): Promise<void>;
}
