import { Router } from 'express';
import { BookController } from './book.controller';
import { BookValidator } from './book.validator';
import { Policy } from 'core/policy';
export declare class BookRoute {
    private _ctrl;
    private _validator;
    private _policy;
    constructor(_ctrl: BookController, _validator: BookValidator, _policy: Policy);
    setupRoutes(router: Router): void;
}
