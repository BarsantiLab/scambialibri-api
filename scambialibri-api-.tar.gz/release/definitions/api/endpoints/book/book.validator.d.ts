export declare class BookValidator {
    getBooks(req: any, res: any, next: any): void;
}
