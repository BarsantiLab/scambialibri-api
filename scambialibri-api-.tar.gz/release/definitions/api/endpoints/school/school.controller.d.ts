export declare class SchoolController {
    getSchools(req: any, res: any, next: any): Promise<void>;
    getSpecialization(req: any, res: any, next: any): Promise<void>;
    getGrades(req: any, res: any, next: any): Promise<void>;
    prepareGradeFilter(req: any, res: any, next: any): Promise<void>;
}
