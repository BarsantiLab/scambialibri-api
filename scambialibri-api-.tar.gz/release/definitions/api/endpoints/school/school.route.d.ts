import { Router } from 'express';
import { SchoolController } from './school.controller';
import { SchoolValidator } from './school.validator';
export declare class SchoolRoute {
    private _ctrl;
    private _validator;
    constructor(_ctrl: SchoolController, _validator: SchoolValidator);
    setupRoutes(router: Router): void;
}
