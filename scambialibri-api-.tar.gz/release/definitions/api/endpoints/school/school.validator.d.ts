export declare class SchoolValidator {
    getSpecializations(req: any, res: any, next: any): void;
    getGrades(req: any, res: any, next: any): void;
    prepareGradeFilter(req: any, res: any, next: any): void;
}
