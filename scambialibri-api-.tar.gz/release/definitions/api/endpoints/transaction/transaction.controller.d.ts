import { TransactionService } from 'services/transaction.service';
export declare class TransactionController {
    private _transactionService;
    constructor(_transactionService: TransactionService);
    createTransaction(req: any, res: any, next: any): Promise<void>;
    cancelTransaction(req: any, res: any, next: any): Promise<void>;
    getPurchases(req: any, res: any, next: any): Promise<void>;
    pairTransaction(req: any, res: any, next: any): Promise<void>;
    sendMessage(req: any, res: any, next: any): Promise<void>;
    getSales(req: any, res: any, next: any): Promise<void>;
}
