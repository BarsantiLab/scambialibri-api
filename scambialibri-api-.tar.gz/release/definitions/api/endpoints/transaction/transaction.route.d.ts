import { Router } from 'express';
import { Policy } from 'core/policy';
import { TransactionController } from './transaction.controller';
import { TransactionValidator } from './transaction.validator';
export declare class TransactionRoute {
    private _ctrl;
    private _validator;
    private _policy;
    constructor(_ctrl: TransactionController, _validator: TransactionValidator, _policy: Policy);
    setupRoutes(router: Router): void;
}
