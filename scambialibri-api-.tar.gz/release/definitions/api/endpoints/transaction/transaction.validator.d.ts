export declare class TransactionValidator {
    createTransaction(req: any, res: any, next: any): void;
    cancelTransaction(req: any, res: any, next: any): void;
    pairTransaction(req: any, res: any, next: any): void;
}
