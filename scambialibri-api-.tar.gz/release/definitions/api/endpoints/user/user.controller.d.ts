import { IRequestSessionHandler } from 'api/request-session-handler';
import { GeoService } from 'services/geo.service';
import { MailService } from 'services/mail.service';
export declare class UserController {
    private _mail;
    private _geo;
    constructor(_mail: MailService, _geo: GeoService);
    login(req: IRequestSessionHandler, res: any, next: any): void;
    logout(req: any, res: any): void;
    signup(req: any, res: any, next: any): Promise<void>;
    completeOnboarding(req: any, res: any, next: any): Promise<void>;
    getUser(req: any, res: any, next: any): Promise<void>;
    getUserSchool(req: any, res: any, next: any): Promise<void>;
    getUserGrade(req: any, res: any, next: any): Promise<void>;
}
