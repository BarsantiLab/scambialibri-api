import { Router } from 'express';
import { UserValidator } from './user.validator';
import { UserController } from 'api/endpoints/user/user.controller';
import { Policy } from 'core/policy';
export declare class UserRoute {
    private _validator;
    private _ctrl;
    private _policy;
    constructor(_validator: UserValidator, _ctrl: UserController, _policy: Policy);
    setupRoutes(router: Router): void;
}
