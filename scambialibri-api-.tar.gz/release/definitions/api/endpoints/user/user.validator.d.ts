export declare class UserValidator {
    login(req: any, res: any, next: any): void;
    signup(req: any, res: any, next: any): void;
    getUser(req: any, res: any, next: any): void;
    getUserSchool(req: any, res: any, next: any): void;
    completeOnboarding(req: any, res: any, next: any): void;
    getUserGrade(req: any, res: any, next: any): void;
}
