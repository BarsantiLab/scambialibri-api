import { BookRoute } from 'api/endpoints/book/book.route';
import { SchoolRoute } from 'api/endpoints/school/school.route';
import { TransactionRoute } from 'api/endpoints/transaction/transaction.route';
import { UserRoute } from 'api/endpoints/user/user.route';
import * as express from 'express';
export declare class RouterFactory {
    private _bookRoute;
    private _schoolRoute;
    private _transactionRoute;
    private _userRoute;
    router: express.Router;
    constructor(_bookRoute: BookRoute, _schoolRoute: SchoolRoute, _transactionRoute: TransactionRoute, _userRoute: UserRoute);
}
