export declare class Configuration {
    log: {
        timestamp: boolean;
        level: string;
        http: boolean;
    };
    google: {
        geoUrl: string;
        token: string;
    };
    mail: {
        apiKey: string;
        domain: string;
        from: string;
        baseDomain: string;
    };
    mongo: {
        user: string;
        password: string;
        host: string;
        database: string;
    };
    http: {
        port: number;
    };
    token: {
        expiration: number;
    };
    test: {
        mongo: {
            user: string;
            password: string;
            host: string;
            database: string;
        };
    };
    debug: {
        sendStackToClient: boolean;
        sendErrorsToClient: boolean;
    };
    constructor();
    setConfiguration(conf?: object): void;
}
