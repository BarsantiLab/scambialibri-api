import * as mongoose from 'mongoose';
import { Configuration } from 'core/config';
import { Logger } from 'core/log';
export declare class Db {
    private _config;
    private _log;
    connection: mongoose.Connection;
    constructor(_config: Configuration, _log: Logger);
    setup(): Promise<any>;
    clearDb(): Promise<void>;
    loadDataFromFile(data: any): Promise<void>;
}
