export declare enum ErrorCode {
    Unauthorized = 0,
    UserInvalidPassword = 1,
    DuplicateMail = 2,
    OnboardingAlreadyCompleted = 3,
    UserNotFound = 4,
    SchoolNotFound = 5,
    BookNotFound = 6,
    GradeNotFound = 7,
    TransactionNotFound = 8,
    SpecializationNotRelatedToSchool = 9,
    GradeNotRelatedToSpecializationOrSchool = 10,
    DuplicateTransaction = 11,
    EndpointNotFound = 12,
    ValidationError = 13,
    UnreachableExternalAPI = 14,
    InternalServerError = 15,
}
export interface IErrorCodeObject {
    code?: number;
    label: ErrorCode;
    message?: string;
    status: 400 | 401 | 403 | 404 | 500;
}
export declare class ApiError extends Error {
    errorCodeObject: IErrorCodeObject;
    data: any;
    constructor(code: ErrorCode, data?: any);
}
