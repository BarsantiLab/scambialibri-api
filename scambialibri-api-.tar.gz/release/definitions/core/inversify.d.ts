import { Container } from 'inversify';
export declare const InversifyContainer: Container;
