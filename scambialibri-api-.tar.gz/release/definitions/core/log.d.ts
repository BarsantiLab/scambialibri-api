import { Configuration } from 'core/config';
import * as express from 'express';
import * as winston from 'winston';
export declare class Logger {
    private _config;
    log: winston.LoggerInstance;
    transports: winston.TransportInstance[];
    constructor(_config: Configuration);
    error(message: any): any;
    debug(message: any): any;
    info(message: any): any;
    silly(message: any): any;
    setupApp(app: express.Application): void;
}
