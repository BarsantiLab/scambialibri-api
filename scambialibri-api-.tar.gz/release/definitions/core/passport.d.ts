import { Configuration } from 'core/config';
import { AuthService } from 'services/auth.service';
export declare class PassportConfiguration {
    private _config;
    private _authService;
    constructor(_config: Configuration, _authService: AuthService);
    initStrategies(): void;
}
