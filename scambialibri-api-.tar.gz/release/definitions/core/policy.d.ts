import * as express from 'express';
export declare enum Role {
    authenticated = 0,
    administrator = 1,
    user = 2,
}
export declare class Policy {
    is(role: Role): express.Handler;
    private _isAuthenticated(req, res);
    private _isAdministrator(req, res);
    private _isUser(req, res);
    private _isRoleValid(req, res, role);
}
