import { Document } from 'mongoose';
import { UserRole } from 'models/user.model';
import { IGrade } from './grade.interface';
import { ISchool } from './school.interface';
import { ISpecialization } from './specialization.interface';
import { ITransaction } from './transaction.interface';
export interface IUser {
    mail: string;
    password: string;
    accessToken: string;
    confirmationToken: string;
    disabled: boolean;
    role: UserRole;
    onboardingCompleted: boolean;
    firstName: string;
    lastName: string;
    phone: string;
    address: string;
    city: string;
    zipCode: string;
    province: string;
    school: ISchool;
    specialization: ISpecialization;
    currentGrade: IGrade;
    futureGrade: IGrade;
    coords: number[];
    transactions: ITransaction[];
}
export declare enum BookStatus {
    new = 0,
    pencilNotes = 1,
    penNotes = 2,
    badConditions = 3,
}
export interface IUserModel extends IUser, Document {
}
