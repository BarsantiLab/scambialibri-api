import * as mongoose from 'mongoose';
import { IBook, IBookModel } from 'interfaces/book.interface';
export declare class BookSchema extends mongoose.Schema implements IBook {
    isbn: string;
    author: string;
    title: string;
    subtitle: string;
    price: number;
    custom: boolean;
    constructor();
}
export declare const Book: mongoose.Model<IBookModel>;
