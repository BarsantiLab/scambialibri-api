import * as mongoose from 'mongoose';
import { IBook } from 'interfaces/book.interface';
import { IGrade, IGradeModel } from 'interfaces/grade.interface';
import { ISchool } from 'interfaces/school.interface';
import { ISpecialization } from 'interfaces/specialization.interface';
export declare class GradeSchema extends mongoose.Schema implements IGrade {
    year: number;
    section: string;
    specialization: ISpecialization;
    school: ISchool;
    defaultBooks: [{
        book: IBook;
        isNecessary: boolean;
        isAdvised: boolean;
        isNewAdoption: boolean;
    }];
    constructor();
}
export declare const Grade: mongoose.Model<IGradeModel>;
