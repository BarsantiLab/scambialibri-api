import * as mongoose from 'mongoose';
import { IMessage, IMessageModel } from 'interfaces/message.interface';
import { ITransaction } from 'interfaces/transaction.interface';
export declare class MessageSchema extends mongoose.Schema implements IMessage {
    from: ITransaction;
    to: ITransaction;
    content: string;
    date: Date;
    constructor();
}
export declare const Message: mongoose.Model<IMessageModel>;
