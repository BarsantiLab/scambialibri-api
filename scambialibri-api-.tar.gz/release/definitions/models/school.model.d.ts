import * as mongoose from 'mongoose';
import { ISchool, ISchoolModel } from 'interfaces/school.interface';
import { ISpecialization } from 'interfaces/specialization.interface';
export declare class SchoolSchema extends mongoose.Schema implements ISchool {
    name: string;
    specializations: [ISpecialization];
    constructor();
}
export declare const School: mongoose.Model<ISchoolModel>;
