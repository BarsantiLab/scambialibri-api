import * as mongoose from 'mongoose';
import { ISchool } from 'interfaces/school.interface';
import { ISpecialization, ISpecializationModel } from 'interfaces/specialization.interface';
export declare class SpecializationSchema extends mongoose.Schema implements ISpecialization {
    name: string;
    school: ISchool;
    constructor();
}
export declare const Specialization: mongoose.Model<ISpecializationModel>;
