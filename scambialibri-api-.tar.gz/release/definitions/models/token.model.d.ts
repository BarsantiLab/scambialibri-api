import * as mongoose from 'mongoose';
import { IToken, ITokenModel, TokenLevel } from 'interfaces/token.interface';
import { IUser } from 'interfaces/user.interface';
export declare class TokenSchema extends mongoose.Schema implements IToken {
    value?: string;
    expireAt?: Date;
    level?: TokenLevel;
    user?: IUser;
    constructor();
}
export declare const Token: mongoose.Model<ITokenModel>;
