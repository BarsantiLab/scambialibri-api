import * as mongoose from 'mongoose';
import { IBook } from 'interfaces/book.interface';
import { IMessage } from 'interfaces/message.interface';
import { ITransaction, ITransactionModel, TransactionStatus } from 'interfaces/transaction.interface';
import { BookStatus, IUser } from 'interfaces/user.interface';
export declare class TransactionSchema extends mongoose.Schema implements ITransaction {
    status: TransactionStatus;
    seller: IUser;
    buyer: IUser;
    paired: ITransaction;
    book: IBook;
    bookStatus: BookStatus;
    additionalMaterial: boolean;
    messages: [IMessage];
    constructor();
}
export declare const Transaction: mongoose.Model<ITransactionModel>;
