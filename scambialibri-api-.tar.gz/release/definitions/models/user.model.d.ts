import * as mongoose from 'mongoose';
import { IGrade } from 'interfaces/grade.interface';
import { ISchool } from 'interfaces/school.interface';
import { ISpecialization } from 'interfaces/specialization.interface';
import { ITransaction } from 'interfaces/transaction.interface';
import { IUser, IUserModel } from 'interfaces/user.interface';
export declare enum UserRole {
    administrator = 0,
    user = 1,
}
export declare class UserSchema extends mongoose.Schema implements IUser {
    mail: string;
    password: string;
    accessToken: string;
    confirmationToken: string;
    disabled: boolean;
    role: UserRole;
    onboardingCompleted: boolean;
    firstName: string;
    lastName: string;
    phone: string;
    address: string;
    city: string;
    zipCode: string;
    province: string;
    school: ISchool;
    specialization: ISpecialization;
    currentGrade: IGrade;
    futureGrade: IGrade;
    coords: number[];
    transactions: ITransaction[];
    constructor();
}
export declare const User: mongoose.Model<IUserModel>;
