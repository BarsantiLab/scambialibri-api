import { ITokenModel, TokenLevel } from 'interfaces/token.interface';
import { IUserModel } from 'interfaces/user.interface';
export declare class AuthService {
    /**
     * Create a new random access token on database
     *
     * @param {IUserModel} user User to whom the token will be assigned
     * @param {number} expiration Expiration time in seconds
     * @param {number} level Token level (phase of account state)
     * @returns {Promise<ITokenModel>} Instance of the saved token
     * @memberof AuthService
     */
    createToken(user: IUserModel, expiration: number, level: TokenLevel): Promise<ITokenModel>;
}
