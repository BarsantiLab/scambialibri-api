import { Configuration } from 'core/config';
export declare class GeoService {
    private _config;
    constructor(_config: Configuration);
    geocode(address: any): Promise<any>;
}
