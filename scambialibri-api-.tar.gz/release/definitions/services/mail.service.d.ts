import { Configuration } from 'core/config';
export declare class MailService {
    private _config;
    _mailgunService: any;
    constructor(_config: Configuration);
    send(conf: IMailConfiguration): Promise<{}>;
}
export interface IMailConfiguration {
    template: string;
    data?: any;
    to: string;
    subject: string;
}
