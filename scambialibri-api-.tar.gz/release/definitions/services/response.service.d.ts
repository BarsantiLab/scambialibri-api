import { Configuration } from 'core/config';
import { Logger } from 'core/log';
export interface IErrorResponseBody {
    message: any;
    stack?: any;
    code?: number;
    data?: any;
}
export declare class ResponseService {
    private _logger;
    private _config;
    constructor(_logger: Logger, _config: Configuration);
    errorMiddleware(err: any, req: any, res: any, next: any): any;
    serverError(err: IErrorResponseBody, req: any, res: any, next: any): any;
    badRequest(err: any, req: any, res: any, next: any): void;
    forbidden(err: any, req: any, res: any, next: any): void;
    unauthorized(err: any, req: any, res: any, next: any): void;
    notFount(err: any, req: any, res: any, next: any): void;
}
