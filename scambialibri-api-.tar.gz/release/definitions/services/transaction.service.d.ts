import { ITransaction } from 'interfaces/transaction.interface';
export declare class TransactionService {
    pairTransactions(trans1: ITransaction, trans2: ITransaction): Promise<void>;
    sendMessage(transaction: ITransaction, content: string): Promise<void>;
}
