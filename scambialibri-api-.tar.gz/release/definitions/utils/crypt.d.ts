export declare function uuid(byteLength: number): string;
export declare function hashPassword(password: string): string;
