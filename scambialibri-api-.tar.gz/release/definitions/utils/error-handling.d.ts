import { Logger } from 'core/log';
export declare function handleRejections(err: any, log: Logger): void;
export declare function printErrors(errors: any[], log: Logger): void;
