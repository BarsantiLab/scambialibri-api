export interface IValidationStep {
    object: any;
    schema: any;
}
export declare const Joi: any;
/**
 * Valida gli oggetti prendendo in input uno schema di Joi. Se la validazione passa chiama la callback, altrimenti lancia un errore di validazione
 *
 * @export
 * @param {(IValidationStep|IValidationStep[])} steps Step di validazione. Può essere un singolo oggetto ValidationStep oppure un array.
 * @param {any} [callback] Callback opzionale chiamata al successo della validazione
 */
export declare function validate(steps: IValidationStep | IValidationStep[], callback?: any): void;
