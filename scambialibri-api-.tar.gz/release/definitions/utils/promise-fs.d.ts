/// <reference types="node" />
import * as fs from 'fs';
export declare let readdir: typeof fs.readdir.__promisify__;
export declare let rename: typeof fs.rename.__promisify__;
export declare let mkdirp: Function;
export declare let rimraf: Function;
export declare let createWriteStream: typeof fs.createWriteStream;
export declare let readFile: (path: string) => Promise<string>;
export declare let checkExist: (path: string) => Promise<{}>;
