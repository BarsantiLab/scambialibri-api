import { Api } from 'api/api';
import { Db } from 'core/db';
export interface ITestGlobals {
    db: Db;
    url: string;
    api: Api;
}
export declare function init_e2e(): Promise<ITestGlobals>;
