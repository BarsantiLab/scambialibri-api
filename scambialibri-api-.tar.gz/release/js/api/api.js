"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const config_1 = require("core/config");
const db_1 = require("core/db");
const log_1 = require("core/log");
const passport_1 = require("core/passport");
const response_service_1 = require("services/response.service");
const router_1 = require("api/router");
const bodyParser = require("body-parser");
const compression = require("compression");
const cors = require("cors");
const express = require("express");
const helmet = require("helmet");
const passport = require("passport");
let Api = class Api {
    constructor(_config, _logger, _db, _passport, _route, _responseService) {
        this._config = _config;
        this._logger = _logger;
        this._db = _db;
        this._passport = _passport;
        this._route = _route;
        this._responseService = _responseService;
    }
    setup() {
        return __awaiter(this, void 0, void 0, function* () {
            this._app = express();
            this._app.use(cors());
            this._app.use(helmet());
            // CSP Protection
            this._app.use(helmet.contentSecurityPolicy({
                directives: {
                    defaultSrc: ["'self'"]
                }
            }));
            // Referrer policy protection
            this._app.use(helmet.referrerPolicy({
                policy: 'same-origin'
            }));
            // Disable cache client-side
            this._app.use(helmet.noCache());
            // Enable gzip compression
            this._app.use(compression());
            // Enable body parser for JSON and querystring
            this._app.use(bodyParser.json());
            this._app.use(bodyParser.urlencoded({ extended: true }));
            // Setup DB connection and models
            yield this._db.setup();
            // Setup passport and its strategies for authentication
            this._app.use(passport.initialize());
            this._passport.initStrategies();
            // Setup logging middleware
            this._logger.setupApp(this._app);
            // Setup controllers routes
            this._app.use(this._route.router);
            // Setup custom error handling
            this._app.use(this._responseService.errorMiddleware.bind(this._responseService));
        });
    }
    listen() {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve) => {
                this._server = this._app.listen(this._config.http.port, () => {
                    this._logger.log.info('Server listening on port ' + this._config.http.port);
                    resolve();
                });
            });
        });
    }
    close() {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve) => {
                this._server.close(() => {
                    this._logger.log.debug('Server connection closed!');
                    resolve();
                });
            });
        });
    }
};
Api = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [config_1.Configuration,
        log_1.Logger,
        db_1.Db,
        passport_1.PassportConfiguration,
        router_1.RouterFactory,
        response_service_1.ResponseService])
], Api);
exports.Api = Api;

//# sourceMappingURL=api.js.map
