"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const grade_model_1 = require("models/grade.model");
const school_model_1 = require("models/school.model");
const error_codes_1 = require("core/error-codes");
const specialiazion_model_1 = require("models/specialiazion.model");
let SchoolController = class SchoolController {
    getSchools(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const schools = yield school_model_1.School.find();
                res.send(schools.map((e) => ({
                    id: e._id.toString(),
                    name: e.name
                })));
            }
            catch (err) {
                next(err);
            }
        });
    }
    getSpecialization(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const school = yield school_model_1.School.findById(req.params.id).populate('specializations');
                if (!school)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.SchoolNotFound);
                const specs = yield specialiazion_model_1.Specialization.find({
                    school: school._id
                });
                res.send(specs.map((e) => ({
                    id: e._id.toString(),
                    name: e.name
                })));
            }
            catch (err) {
                next(err);
            }
        });
    }
    getGrades(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const grades = yield grade_model_1.Grade.find({
                    school: req.params.school,
                    specialization: req.params.spec
                });
                res.send(grades.map((e) => ({
                    id: e._id.toString(),
                    year: e.year,
                    section: e.section
                })));
            }
            catch (err) {
                next(err);
            }
        });
    }
    prepareGradeFilter(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const grades = yield grade_model_1.Grade.find({
                    school: req.params.school
                }).populate('specialization').exec();
                res.send(grades.map((e) => ({
                    id: e._id.toString(),
                    year: e.year,
                    section: e.section,
                    specializationName: e.specialization.name
                })));
            }
            catch (err) {
                next(err);
            }
        });
    }
};
SchoolController = __decorate([
    inversify_1.injectable()
], SchoolController);
exports.SchoolController = SchoolController;

//# sourceMappingURL=school.controller.js.map
