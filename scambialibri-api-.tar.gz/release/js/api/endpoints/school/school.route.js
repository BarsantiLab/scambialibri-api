"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const school_controller_1 = require("./school.controller");
const school_validator_1 = require("./school.validator");
let SchoolRoute = class SchoolRoute {
    constructor(_ctrl, _validator) {
        this._ctrl = _ctrl;
        this._validator = _validator;
    }
    setupRoutes(router) {
        router.get('/school', this._ctrl.getSchools.bind(this._ctrl));
        router.get('/school/:id/specialization', this._validator.getSpecializations, this._ctrl.getSpecialization.bind(this._ctrl));
        router.get('/school/:school/specialization/:spec/grade', this._validator.getGrades, this._ctrl.getGrades.bind(this._ctrl));
        router.get('/school/:school/grade/prepare', this._validator.prepareGradeFilter, this._ctrl.prepareGradeFilter.bind(this._ctrl));
    }
};
SchoolRoute = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [school_controller_1.SchoolController,
        school_validator_1.SchoolValidator])
], SchoolRoute);
exports.SchoolRoute = SchoolRoute;

//# sourceMappingURL=school.route.js.map
