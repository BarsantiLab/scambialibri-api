"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const mongoose = require("mongoose");
const error_codes_1 = require("core/error-codes");
const transaction_interface_1 = require("interfaces/transaction.interface");
const book_model_1 = require("models/book.model");
const message_model_1 = require("models/message.model");
const transaction_model_1 = require("models/transaction.model");
const transaction_service_1 = require("services/transaction.service");
let TransactionController = class TransactionController {
    constructor(_transactionService) {
        this._transactionService = _transactionService;
    }
    createTransaction(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const book = yield book_model_1.Book.findById(req.body.book);
                if (!book)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.BookNotFound, { id: req.body.book });
                const transaction = yield transaction_model_1.Transaction.findOne({
                    book: req.body.book,
                    user: req.user._id
                });
                if (transaction)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.DuplicateTransaction, {
                        transaction: transaction._id.toString()
                    });
                const transactionData = {
                    book: mongoose.Types.ObjectId(req.body.book),
                    messages: [],
                    status: transaction_interface_1.TransactionStatus.free
                };
                if (req.body.mode === 'sell') {
                    transactionData.seller = req.user._id;
                    transactionData.bookStatus = req.body.bookStatus;
                    transactionData.additionalMaterial = req.body.additionalMaterial;
                }
                else {
                    transactionData.buyer = req.user._id;
                }
                const newTransaction = yield new transaction_model_1.Transaction(transactionData).save();
                res.send({
                    id: newTransaction._id.toString(),
                    bookStatus: newTransaction.bookStatus,
                    additionalMaterial: newTransaction.additionalMaterial
                });
            }
            catch (err) {
                next(err);
            }
        });
    }
    cancelTransaction(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const trans = yield transaction_model_1.Transaction.findOne({
                    _id: req.params.id,
                    $or: [{
                            seller: req.user._id
                        }, {
                            buyer: req.user._id
                        }]
                });
                if (!trans)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.TransactionNotFound, { id: req.params.id });
                yield transaction_model_1.Transaction.findByIdAndRemove(req.params.id);
                res.send({ status: 'ok' });
            }
            catch (err) {
                next(err);
            }
        });
    }
    getPurchases(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            // TODO: sort buyer transaction
            try {
                const purchases = yield transaction_model_1.Transaction.find({
                    buyer: req.user._id
                }).populate('book').exec();
                const out = [];
                for (const trans of purchases) {
                    const tmpObj = {
                        id: trans._id.toString(),
                        status: trans.status,
                        book: {
                            author: trans.book.author,
                            isbn: trans.book.isbn,
                            title: trans.book.title,
                            subtitle: trans.book.subtitle
                        }
                    };
                    if (trans.status === transaction_interface_1.TransactionStatus.free) {
                        const sales = yield transaction_model_1.Transaction.find({
                            book: trans.book._id,
                            _id: {
                                $ne: trans._id
                            },
                            seller: {
                                $ne: null
                            }
                        }).populate('seller').exec();
                        // TODO: sort sales by points
                        tmpObj.sales = sales.map(sale => ({
                            id: sale._id.toString(),
                            status: sale.status,
                            bookStatus: sale.bookStatus,
                            additionalMaterial: sale.additionalMaterial || false,
                            seller: {
                                firstName: sale.seller.firstName,
                                lastName: sale.seller.lastName
                            }
                        }));
                    }
                    if (trans.status === transaction_interface_1.TransactionStatus.pending) {
                        const paired = yield transaction_model_1.Transaction.findById(trans.paired).populate({
                            path: 'seller',
                            populate: {
                                path: 'school',
                                model: 'School' // TODO: can I remove it?
                            }
                        }).exec();
                        if (!paired)
                            throw new error_codes_1.ApiError(error_codes_1.ErrorCode.TransactionNotFound, { transaction: trans.paired });
                        tmpObj.pairedUser = {
                            firstName: paired.seller.firstName,
                            lastName: paired.seller.lastName,
                            mail: paired.seller.mail,
                            address: paired.seller.address,
                            province: paired.seller.province,
                            city: paired.seller.city,
                            phone: paired.seller.phone,
                            schoolName: paired.seller.school.name
                        };
                        const messages = yield message_model_1.Message.find({
                            _id: { $in: trans.messages }
                        });
                        tmpObj.messages = messages.map((msg) => ({
                            sent: msg.from === req.user._id,
                            content: msg.content,
                            date: msg.date
                        }));
                    }
                    out.push(tmpObj);
                }
                res.send(out);
            }
            catch (err) {
                next(err);
            }
        });
    }
    pairTransaction(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // TODO: rename params: trans1 -> buyerTrans, trans2 -> sellerTrans
                // TODO: check if the caller user is the buyer of buyerTrans
                const trans1 = yield transaction_model_1.Transaction.findById(req.params.id);
                if (!trans1)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.TransactionNotFound, { transaction: req.params.id });
                // TODO: check if the caller user is not the seller of sellerTrans
                const trans2 = yield transaction_model_1.Transaction.findById(req.body.transaction);
                if (!trans2)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.TransactionNotFound, { transaction: req.body.transaction });
                yield this._transactionService.pairTransactions(trans1, trans2);
                res.send({ status: 'ok' });
            }
            catch (err) {
                next(err);
            }
        });
    }
    sendMessage(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // await this._transactionService.s
            }
            catch (err) {
                next(err);
            }
        });
    }
    getSales(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            res.sendStatus(418);
        });
    }
};
TransactionController = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [transaction_service_1.TransactionService])
], TransactionController);
exports.TransactionController = TransactionController;

//# sourceMappingURL=transaction.controller.js.map
