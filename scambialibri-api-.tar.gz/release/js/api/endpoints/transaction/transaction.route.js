"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const policy_1 = require("core/policy");
const transaction_controller_1 = require("./transaction.controller");
const transaction_validator_1 = require("./transaction.validator");
let TransactionRoute = class TransactionRoute {
    constructor(_ctrl, _validator, _policy) {
        this._ctrl = _ctrl;
        this._validator = _validator;
        this._policy = _policy;
    }
    setupRoutes(router) {
        router.post('/transaction', this._policy.is(policy_1.Role.authenticated), this._validator.createTransaction, this._ctrl.createTransaction.bind(this._ctrl));
        router.delete('/transaction/:id', this._policy.is(policy_1.Role.authenticated), this._validator.cancelTransaction, this._ctrl.cancelTransaction.bind(this._ctrl));
        router.get('/transaction/purchases', this._policy.is(policy_1.Role.authenticated), this._ctrl.getPurchases.bind(this._ctrl));
        router.get('/transaction/sales', this._policy.is(policy_1.Role.authenticated), this._ctrl.getSales.bind(this._ctrl));
        router.post('/transaction/:id/pair', this._policy.is(policy_1.Role.authenticated), this._validator.pairTransaction, this._ctrl.pairTransaction.bind(this._ctrl));
    }
};
TransactionRoute = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [transaction_controller_1.TransactionController,
        transaction_validator_1.TransactionValidator,
        policy_1.Policy])
], TransactionRoute);
exports.TransactionRoute = TransactionRoute;

//# sourceMappingURL=transaction.route.js.map
