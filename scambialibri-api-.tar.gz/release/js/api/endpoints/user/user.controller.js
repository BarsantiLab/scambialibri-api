"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const passport = require("passport");
const error_codes_1 = require("core/error-codes");
const grade_model_1 = require("models/grade.model");
const school_model_1 = require("models/school.model");
const specialiazion_model_1 = require("models/specialiazion.model");
const user_model_1 = require("models/user.model");
const geo_service_1 = require("services/geo.service");
const mail_service_1 = require("services/mail.service");
let UserController = class UserController {
    constructor(_mail, _geo) {
        this._mail = _mail;
        this._geo = _geo;
    }
    login(req, res, next) {
        try {
            passport.authenticate('local-login', (err, user, info) => {
                if (err)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.InternalServerError, err);
                if (!user)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.Unauthorized);
                res.send({
                    id: user._id.toString(),
                    accessToken: user.accessToken,
                    onboardingCompleted: user.onboardingCompleted
                });
            })(req, res, next);
        }
        catch (err) {
            next(err);
        }
    }
    logout(req, res) { }
    signup(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                passport.authenticate('local-signup', (err, user, info) => __awaiter(this, void 0, void 0, function* () {
                    if (err) {
                        if (err.errorCodeObject.code === 1005)
                            throw new error_codes_1.ApiError(error_codes_1.ErrorCode.DuplicateMail, err);
                        throw new error_codes_1.ApiError(error_codes_1.ErrorCode.InternalServerError, err);
                    }
                    yield this._mail.send({
                        template: 'confirm-account',
                        to: user.mail,
                        subject: 'Scambialibri.it - conferma account',
                        data: {
                            token: user.confirmationToken
                        }
                    });
                    res.send({ status: 'ok' });
                }))(req, res, next);
            }
            catch (err) {
                next(err);
            }
        });
    }
    completeOnboarding(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const user = yield user_model_1.User.findOne({ confirmationToken: req.query.token });
                if (!user)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.UserNotFound);
                if (user.onboardingCompleted)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.OnboardingAlreadyCompleted);
                const school = yield school_model_1.School.findById(req.body.school);
                const spec = yield specialiazion_model_1.Specialization.findById(req.body.specialization);
                const grade = yield grade_model_1.Grade.findById(req.body.grade);
                const futureGrade = yield grade_model_1.Grade.findOne({
                    specialization: spec._id,
                    school: school._id,
                    section: grade.section,
                    year: grade.year + 1
                });
                if (!grade) {
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.GradeNotFound, {
                        grade: req.body.grade
                    });
                }
                if (!spec.school.equals(school._id)) {
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.SpecializationNotRelatedToSchool, {
                        specialiazion: spec._id.toString(),
                        school: school._id.toString()
                    });
                }
                if (!grade.school.equals(school._id) || !grade.specialization.equals(spec._id)) {
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.GradeNotRelatedToSpecializationOrSchool, {
                        grade: grade._id.toString(),
                        specialiazion: spec._id.toString(),
                        school: school._id.toString()
                    });
                }
                user.firstName = req.body.firstName;
                user.lastName = req.body.lastName;
                user.phone = req.body.phone;
                user.address = req.body.address;
                user.city = req.body.city;
                user.zipCode = req.body.zipCode;
                user.province = req.body.province;
                user.school = school._id;
                user.specialization = spec._id;
                user.currentGrade = grade._id;
                if (futureGrade)
                    user.futureGrade = futureGrade._id;
                user.onboardingCompleted = true;
                // TODO: test this
                const geoData = yield this._geo.geocode(`${user.address}, ${user.zipCode} ${user.city} (${user.province})`);
                const loc = geoData.results[0].geometry.location;
                user.coords = [loc.lng, loc.lat];
                console.log(user._id);
                yield user_model_1.User.findByIdAndUpdate(user._id, user);
                res.send({ status: 'ok' });
            }
            catch (err) {
                next(err);
            }
        });
    }
    getUser(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const user = yield user_model_1.User.findById(req.params.id).populate(req.query.populate);
                if (!user)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.UserNotFound, { id: req.params.id });
                // TODO: sanitize output
                res.send(user);
            }
            catch (err) {
                next(err);
            }
        });
    }
    getUserSchool(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const user = yield user_model_1.User.findById(req.params.id);
                if (!user)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.UserNotFound, { user: req.params.id });
                const school = yield school_model_1.School.findById(user.school);
                if (!school)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.SchoolNotFound, { school: user.school });
                res.send({
                    id: school._id.toString(),
                    name: school.name
                });
            }
            catch (err) {
                next(err);
            }
        });
    }
    getUserGrade(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const user = yield user_model_1.User.findById(req.params.id);
                if (!user)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.UserNotFound, { id: req.params.id });
                const grade = yield grade_model_1.Grade.findById(user.currentGrade);
                if (!grade)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.GradeNotFound, { grade: user.currentGrade });
                res.send({
                    id: grade._id.toString(),
                    year: grade.year,
                    section: grade.section
                });
            }
            catch (err) {
                next(err);
            }
        });
    }
};
UserController = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [mail_service_1.MailService,
        geo_service_1.GeoService])
], UserController);
exports.UserController = UserController;
// import { User, UserRole } from 'models/user.model';
// import { hashPassword } from 'utils/crypt';
// (async () => {
//     const u = new User({
//         activated: true,
//         mail: 'davide.ross93@gmail.com',
//         password: hashPassword('davide12'),
//         role: UserRole.administrator
//     });
//     await u.save();
//     console.log(u);
// })();

//# sourceMappingURL=user.controller.js.map
