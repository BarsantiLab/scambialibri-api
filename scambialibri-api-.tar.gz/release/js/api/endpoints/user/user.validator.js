"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const joi_extension_1 = require("utils/joi-extension");
let UserValidator = class UserValidator {
    login(req, res, next) {
        joi_extension_1.validate({
            object: req.body,
            schema: joi_extension_1.Joi.object().keys({
                mail: joi_extension_1.Joi.string().email().required(),
                password: joi_extension_1.Joi.string().required()
            })
        }, next);
    }
    signup(req, res, next) {
        joi_extension_1.validate({
            object: req.body,
            schema: joi_extension_1.Joi.object().keys({
                mail: joi_extension_1.Joi.string().email().required(),
                password: joi_extension_1.Joi.string().required()
            })
        }, next);
    }
    getUser(req, res, next) {
        joi_extension_1.validate([{
                object: req.params,
                schema: joi_extension_1.Joi.object().keys({
                    id: joi_extension_1.Joi.string().objectId().required()
                })
            }, {
                object: req.query,
                schema: joi_extension_1.Joi.object().keys({
                    populate: joi_extension_1.Joi.array().items(joi_extension_1.Joi.string())
                })
            }], next);
    }
    getUserSchool(req, res, next) {
        joi_extension_1.validate({
            object: req.params,
            schema: joi_extension_1.Joi.object().keys({
                id: joi_extension_1.Joi.string().objectId().required()
            })
        }, next);
    }
    completeOnboarding(req, res, next) {
        joi_extension_1.validate([{
                object: req.query,
                schema: joi_extension_1.Joi.object().keys({
                    token: joi_extension_1.Joi.string().required()
                })
            }, {
                object: req.body,
                schema: joi_extension_1.Joi.object().keys({
                    school: joi_extension_1.Joi.string().objectId().required(),
                    specialization: joi_extension_1.Joi.string().objectId().required(),
                    grade: joi_extension_1.Joi.string().objectId().required(),
                    firstName: joi_extension_1.Joi.string().required(),
                    lastName: joi_extension_1.Joi.string().required(),
                    phone: joi_extension_1.Joi.string().required(),
                    address: joi_extension_1.Joi.string().required(),
                    city: joi_extension_1.Joi.string().required(),
                    zipCode: joi_extension_1.Joi.string().required(),
                    province: joi_extension_1.Joi.string().required(),
                })
            }], next);
    }
    getUserGrade(req, res, next) {
        joi_extension_1.validate({
            object: req.params,
            schema: joi_extension_1.Joi.object().keys({
                id: joi_extension_1.Joi.string().objectId().required()
            })
        }, next);
    }
};
UserValidator = __decorate([
    inversify_1.injectable()
], UserValidator);
exports.UserValidator = UserValidator;

//# sourceMappingURL=user.validator.js.map
