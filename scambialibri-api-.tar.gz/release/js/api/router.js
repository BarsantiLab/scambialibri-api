"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const book_route_1 = require("api/endpoints/book/book.route");
const school_route_1 = require("api/endpoints/school/school.route");
const transaction_route_1 = require("api/endpoints/transaction/transaction.route");
const user_route_1 = require("api/endpoints/user/user.route");
const express = require("express");
const error_codes_1 = require("core/error-codes");
let RouterFactory = class RouterFactory {
    constructor(_bookRoute, _schoolRoute, _transactionRoute, _userRoute) {
        this._bookRoute = _bookRoute;
        this._schoolRoute = _schoolRoute;
        this._transactionRoute = _transactionRoute;
        this._userRoute = _userRoute;
        this.router = express.Router();
        this._bookRoute.setupRoutes(this.router);
        this._schoolRoute.setupRoutes(this.router);
        this._transactionRoute.setupRoutes(this.router);
        this._userRoute.setupRoutes(this.router);
        this.router.all('*', (req, res, next) => {
            next(new error_codes_1.ApiError(error_codes_1.ErrorCode.EndpointNotFound));
        });
    }
};
RouterFactory = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [book_route_1.BookRoute,
        school_route_1.SchoolRoute,
        transaction_route_1.TransactionRoute,
        user_route_1.UserRoute])
], RouterFactory);
exports.RouterFactory = RouterFactory;

//# sourceMappingURL=router.js.map
