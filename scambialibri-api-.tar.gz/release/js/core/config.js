"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
// import { checkExist } from 'utils/promise-fs';
const inversify_1 = require("inversify");
const defaultConf = {
    debug: {
        sendErrorsToClient: true,
        sendStackToClient: true
    },
    google: {
        geoUrl: 'https://maps.googleapis.com/maps/api/geocode/json',
        token: 'AIzaSyDassqWcpf1kl0v4_T8ZiVtgOZYatrLs3w'
    },
    http: {
        port: 1337
    },
    log: {
        http: true,
        level: 'debug',
        timestamp: true,
    },
    mail: {
        apiKey: 'key-fee6b455d644bedebf9f5a53a08feaf7',
        domain: 'sandbox470e6f41e2444c1daeeeffea13957418.mailgun.org',
        from: 'noreply@scambialibri.it',
        baseDomain: 'http://localhost:8080'
    },
    mongo: {
        database: 'Scambialibri',
        host: 'localhost',
        password: null,
        user: null
    },
    test: {
        mongo: {
            database: 'Scambialibri-test',
            host: 'localhost',
            password: null,
            user: null
        }
    },
    token: {
        expiration: 2000000
    }
};
let Configuration = class Configuration {
    constructor() {
        this.setConfiguration();
        // TODO: load configuration from env/cmd line arguments
    }
    setConfiguration(conf = {}) {
        const c = _.merge(defaultConf, conf);
        Object.assign(this, c);
    }
};
Configuration = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [])
], Configuration);
exports.Configuration = Configuration;

//# sourceMappingURL=config.js.map
