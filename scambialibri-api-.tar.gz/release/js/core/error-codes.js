"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ErrorCode;
(function (ErrorCode) {
    ErrorCode[ErrorCode["Unauthorized"] = 0] = "Unauthorized";
    ErrorCode[ErrorCode["UserInvalidPassword"] = 1] = "UserInvalidPassword";
    ErrorCode[ErrorCode["DuplicateMail"] = 2] = "DuplicateMail";
    ErrorCode[ErrorCode["OnboardingAlreadyCompleted"] = 3] = "OnboardingAlreadyCompleted";
    ErrorCode[ErrorCode["UserNotFound"] = 4] = "UserNotFound";
    ErrorCode[ErrorCode["SchoolNotFound"] = 5] = "SchoolNotFound";
    ErrorCode[ErrorCode["BookNotFound"] = 6] = "BookNotFound";
    ErrorCode[ErrorCode["GradeNotFound"] = 7] = "GradeNotFound";
    ErrorCode[ErrorCode["TransactionNotFound"] = 8] = "TransactionNotFound";
    ErrorCode[ErrorCode["SpecializationNotRelatedToSchool"] = 9] = "SpecializationNotRelatedToSchool";
    ErrorCode[ErrorCode["GradeNotRelatedToSpecializationOrSchool"] = 10] = "GradeNotRelatedToSpecializationOrSchool";
    ErrorCode[ErrorCode["DuplicateTransaction"] = 11] = "DuplicateTransaction";
    ErrorCode[ErrorCode["EndpointNotFound"] = 12] = "EndpointNotFound";
    ErrorCode[ErrorCode["ValidationError"] = 13] = "ValidationError";
    ErrorCode[ErrorCode["UnreachableExternalAPI"] = 14] = "UnreachableExternalAPI";
    ErrorCode[ErrorCode["InternalServerError"] = 15] = "InternalServerError";
})(ErrorCode = exports.ErrorCode || (exports.ErrorCode = {}));
class ApiError extends Error {
    constructor(code, data) {
        if (!errorsMap.has(code)) {
            super('Invalid error code thrown');
        }
        else {
            const errorCodeObject = errorsMap.get(code);
            super(errorCodeObject.message);
            this.errorCodeObject = errorCodeObject;
            this.data = data;
        }
        // Restore prototype chain
        // https://www.typescriptlang.org/docs/handbook/release-notes/typescript-2-2.html
        Object.setPrototypeOf(this, new.target.prototype);
    }
}
exports.ApiError = ApiError;
const errorsMap = new Map();
const errors = [{
        code: 1999,
        label: ErrorCode.ValidationError,
        message: 'Validation error',
        status: 400
    }, {
        code: 1003,
        label: ErrorCode.UserNotFound,
        message: 'User not found',
        status: 401
    }, {
        code: 1004,
        label: ErrorCode.UserInvalidPassword,
        message: 'Invalid password',
        status: 401
    }, {
        code: 1005,
        label: ErrorCode.DuplicateMail,
        message: 'Duplicate e-mail address',
        status: 400
    }, {
        code: 1006,
        label: ErrorCode.OnboardingAlreadyCompleted,
        message: 'Onboarding already completed',
        status: 400
    }, {
        code: 2001,
        label: ErrorCode.SchoolNotFound,
        message: 'School not found',
        status: 404
    }, {
        code: 9997,
        label: ErrorCode.EndpointNotFound,
        message: 'API endpoint not found',
        status: 404
    }, {
        code: 9999,
        label: ErrorCode.InternalServerError,
        message: 'Internal server error',
        status: 500
    }, {
        code: 9998,
        label: ErrorCode.Unauthorized,
        message: 'Unauthorized',
        status: 401
    }, {
        code: 3001,
        label: ErrorCode.BookNotFound,
        message: 'Book not found',
        status: 404
    }, {
        code: 3002,
        label: ErrorCode.TransactionNotFound,
        message: 'Transaction not found',
        status: 404
    }, {
        code: 3003,
        label: ErrorCode.SpecializationNotRelatedToSchool,
        message: 'Specialization not related to school',
        status: 400
    }, {
        code: 3004,
        label: ErrorCode.GradeNotRelatedToSpecializationOrSchool,
        message: 'Grade not related to specialization or school',
        status: 400
    }, {
        code: 3005,
        label: ErrorCode.GradeNotFound,
        message: 'Grade not found',
        status: 404
    }, {
        code: 3006,
        label: ErrorCode.DuplicateTransaction,
        message: 'Duplicate transaction',
        status: 400
    }, {
        code: 9996,
        label: ErrorCode.UnreachableExternalAPI,
        message: 'Unreachable external API',
        status: 400
    }];
for (const error of errors) {
    errorsMap.set(error.label, error);
}

//# sourceMappingURL=error-codes.js.map
