"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("core/config");
const inversify_1 = require("inversify");
const dateFormat = require("dateformat");
const expressWinston = require("express-winston");
const winston = require("winston");
const winstonCommon = require("winston/lib/winston/common");
let Logger = class Logger {
    constructor(_config) {
        this._config = _config;
        this.transports = [];
        winston.transports.Console.prototype.log = function (level, message, meta, callback) {
            const output = winstonCommon.log(Object.assign({}, this, {
                level, message, meta
            }));
            console[level in console ? level : 'log'](output);
            setImmediate(callback, null, true);
        };
        if (process.env.PC_SILENT !== 'true') {
            this.transports.push(new winston.transports.Console({
                colorize: true,
                json: false,
                stderrLevels: ['error'],
                timestamp: (this._config.log.timestamp) ? () => {
                    return winston.config.colorize('data', dateFormat(new Date(), 'isoDateTime'));
                } : false,
                useTimestamp: this._config.log.level
            }));
        }
        this.log = new winston.Logger({
            level: this._config.log.level,
            transports: this.transports
        });
        this.log.info(`Logger: log level ${this._config.log.level}`);
    }
    error(message) {
        return this.log.error(message);
    }
    debug(message) {
        return this.log.debug(message);
    }
    info(message) {
        return this.log.log('info', message);
    }
    silly(message) {
        return this.log.log('silly', message);
    }
    setupApp(app) {
        if (this._config.log.http) {
            app.use(expressWinston.logger({
                colorize: true,
                meta: false,
                msg: '{{req.method}} {{req.url}} {{res.responseTime}}ms {{res.statusCode}}',
                winstonInstance: this.log
            }));
        }
    }
};
Logger = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [config_1.Configuration])
], Logger);
exports.Logger = Logger;

//# sourceMappingURL=log.js.map
