"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const passport_http_bearer_1 = require("passport-http-bearer");
const passport_local_1 = require("passport-local");
const config_1 = require("core/config");
const error_codes_1 = require("core/error-codes");
const auth_service_1 = require("services/auth.service");
const token_interface_1 = require("interfaces/token.interface");
const token_model_1 = require("models/token.model");
const user_model_1 = require("models/user.model");
const bcrypt = require("bcrypt");
const passport = require("passport");
const crypt_1 = require("utils/crypt");
const policy_1 = require("./policy");
let PassportConfiguration = class PassportConfiguration {
    constructor(_config, _authService) {
        this._config = _config;
        this._authService = _authService;
    }
    initStrategies() {
        passport.serializeUser((user, done) => {
            done(null, user);
        });
        passport.deserializeUser((id, done) => {
            user_model_1.User.findOne({ id }).exec(done);
        });
        // ===== LOCAL LOGIN ======================================================================
        passport.use('local-login', new passport_local_1.Strategy({
            passwordField: 'password',
            usernameField: 'mail'
        }, (mail, password, done) => __awaiter(this, void 0, void 0, function* () {
            if (!mail || !password) {
                return done(null, false);
            }
            try {
                const user = yield user_model_1.User.findOne({ mail });
                if (!user) {
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.UserNotFound);
                }
                if (!bcrypt.compareSync(password, user.password)) {
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.UserInvalidPassword);
                }
                const expiration = this._config.token.expiration;
                const token = yield this._authService.createToken(user, expiration, token_interface_1.TokenLevel.authenticate);
                user.accessToken = token.value;
                return done(null, user);
            }
            catch (err) {
                done(err, null);
            }
        })));
        // ===== LOCAL SIGNUP =====================================================================
        passport.use('local-signup', new passport_local_1.Strategy({
            usernameField: 'mail',
            passwordField: 'password',
            passReqToCallback: true
        }, (req, mail, pass, done) => __awaiter(this, void 0, void 0, function* () {
            try {
                const user = yield user_model_1.User.findOne({ mail });
                if (user)
                    throw new error_codes_1.ApiError(error_codes_1.ErrorCode.DuplicateMail);
                const newUser = yield new user_model_1.User({
                    mail,
                    password: crypt_1.hashPassword(pass),
                    confirmationToken: crypt_1.uuid(32),
                    role: policy_1.Role.user
                }).save();
                done(null, newUser);
            }
            catch (err) {
                done(err, null);
            }
        })));
        // ===== BEARER STRATEGY ==================================================================
        passport.use(new passport_http_bearer_1.Strategy((accessToken, done) => __awaiter(this, void 0, void 0, function* () {
            const token = yield token_model_1.Token.findOne({
                expireAt: {
                    $gt: new Date()
                },
                level: token_interface_1.TokenLevel.authenticate,
                value: accessToken
            }).populate('user');
            if (!token || !token.user) {
                return done(null, false);
            }
            const user = token.user;
            user.accessToken = token.value;
            done(null, user);
        })));
        // TODO: integrate bearer-reset-password strategy
        // TODO: integrate bearer-user-activation strategy
    }
};
PassportConfiguration = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [config_1.Configuration,
        auth_service_1.AuthService])
], PassportConfiguration);
exports.PassportConfiguration = PassportConfiguration;

//# sourceMappingURL=passport.js.map
