"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const passport = require("passport");
var Role;
(function (Role) {
    Role[Role["authenticated"] = 0] = "authenticated";
    Role[Role["administrator"] = 1] = "administrator";
    Role[Role["user"] = 2] = "user";
})(Role = exports.Role || (exports.Role = {}));
let Policy = class Policy {
    is(role) {
        return (req, res, next) => {
            this
                ._isRoleValid(req, res, role)
                .then(next)
                .catch(next);
        };
    }
    _isAuthenticated(req, res) {
        return new Promise((resolve, reject) => {
            passport.authenticate('bearer')(req, res, () => {
                resolve();
            });
        });
    }
    _isAdministrator(req, res) {
        return new Promise((resolve, reject) => {
            passport.authenticate('bearer')(req, res, () => {
                if (req.user.role !== Role.administrator)
                    reject({ status: 403 });
                else
                    resolve();
            });
        });
    }
    _isUser(req, res) {
        return new Promise((resolve, reject) => {
            passport.authenticate('bearer')(req, res, () => {
                if (req.user.role !== Role.user)
                    reject({ status: 403 });
                else
                    resolve();
            });
        });
    }
    _isRoleValid(req, res, role) {
        switch (role) {
            case Role.authenticated: return this._isAuthenticated(req, res);
            case Role.administrator: return this._isAdministrator(req, res);
            case Role.user: return this._isUser(req, res);
            default: throw Error('Invalid role ' + role);
        }
    }
};
Policy = __decorate([
    inversify_1.injectable()
], Policy);
exports.Policy = Policy;

//# sourceMappingURL=policy.js.map
