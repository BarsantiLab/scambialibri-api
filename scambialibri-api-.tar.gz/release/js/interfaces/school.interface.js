"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

//# sourceMappingURL=school.interface.js.map
