"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TokenLevel;
(function (TokenLevel) {
    TokenLevel[TokenLevel["authenticate"] = 0] = "authenticate";
    TokenLevel[TokenLevel["resetPassword"] = 1] = "resetPassword";
    TokenLevel[TokenLevel["activation"] = 2] = "activation";
})(TokenLevel = exports.TokenLevel || (exports.TokenLevel = {}));

//# sourceMappingURL=token.interface.js.map
