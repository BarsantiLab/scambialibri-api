"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TransactionStatus;
(function (TransactionStatus) {
    TransactionStatus["free"] = "free";
    TransactionStatus["pending"] = "pending";
    TransactionStatus["closed"] = "closed";
})(TransactionStatus = exports.TransactionStatus || (exports.TransactionStatus = {}));

//# sourceMappingURL=transaction.interface.js.map
