"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var BookStatus;
(function (BookStatus) {
    BookStatus[BookStatus["new"] = 0] = "new";
    BookStatus[BookStatus["pencilNotes"] = 1] = "pencilNotes";
    BookStatus[BookStatus["penNotes"] = 2] = "penNotes";
    BookStatus[BookStatus["badConditions"] = 3] = "badConditions";
})(BookStatus = exports.BookStatus || (exports.BookStatus = {}));

//# sourceMappingURL=user.interface.js.map
