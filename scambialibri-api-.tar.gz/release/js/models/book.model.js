"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
class BookSchema extends mongoose.Schema {
    constructor() {
        super({
            isbn: String,
            price: Number,
            author: String,
            subtitle: String,
            title: String,
            custom: Boolean
        });
    }
}
exports.BookSchema = BookSchema;
// tslint:disable-next-line:variable-name
exports.Book = mongoose.model('Book', new BookSchema());

//# sourceMappingURL=book.model.js.map
