"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
class GradeSchema extends mongoose.Schema {
    constructor() {
        super({
            year: Number,
            section: String,
            specialization: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Specialization'
            },
            school: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'School'
            },
            books: [{
                    book: {
                        type: mongoose.Schema.Types.ObjectId,
                        rel: 'Book'
                    },
                    isNecessary: Boolean,
                    isAdvised: Boolean,
                    isNewAdoption: Boolean
                }]
        });
    }
}
exports.GradeSchema = GradeSchema;
// tslint:disable-next-line:variable-name
exports.Grade = mongoose.model('Grade', new GradeSchema());

//# sourceMappingURL=grade.model.js.map
