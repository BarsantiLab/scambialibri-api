"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
class MessageSchema extends mongoose.Schema {
    constructor() {
        super({
            from: {
                ref: 'Transaction',
                type: mongoose.Schema.Types.ObjectId
            },
            to: {
                ref: 'Transaction',
                type: mongoose.Schema.Types.ObjectId
            },
            content: String,
            date: Date
        });
    }
}
exports.MessageSchema = MessageSchema;
// tslint:disable-next-line:variable-name
exports.Message = mongoose.model('Message', new MessageSchema());

//# sourceMappingURL=message.model.js.map
