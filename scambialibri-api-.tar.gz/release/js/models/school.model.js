"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
class SchoolSchema extends mongoose.Schema {
    constructor() {
        super({
            name: String,
            specializations: [{
                    ref: 'Specialization',
                    type: mongoose.Schema.Types.ObjectId
                }]
        });
    }
}
exports.SchoolSchema = SchoolSchema;
// tslint:disable-next-line:variable-name
exports.School = mongoose.model('School', new SchoolSchema());

//# sourceMappingURL=school.model.js.map
