"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
class SpecializationSchema extends mongoose.Schema {
    constructor() {
        super({
            name: String,
            school: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'School'
            }
        });
    }
}
exports.SpecializationSchema = SpecializationSchema;
// tslint:disable-next-line:variable-name
exports.Specialization = mongoose.model('Specialization', new SpecializationSchema());

//# sourceMappingURL=specialiazion.model.js.map
