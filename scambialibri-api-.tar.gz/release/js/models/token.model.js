"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
class TokenSchema extends mongoose.Schema {
    constructor() {
        super({
            expireAt: {
                required: true,
                type: Date
            },
            level: {
                required: true,
                type: Number
            },
            user: {
                ref: 'User',
                type: mongoose.Schema.Types.ObjectId
            },
            value: {
                required: true,
                type: String
            }
        });
    }
}
exports.TokenSchema = TokenSchema;
// tslint:disable-next-line:variable-name
exports.Token = mongoose.model('Token', new TokenSchema());

//# sourceMappingURL=token.model.js.map
