"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
class TransactionSchema extends mongoose.Schema {
    constructor() {
        super({
            status: String,
            seller: {
                ref: 'User',
                type: mongoose.Schema.Types.ObjectId
            },
            buyer: {
                ref: 'User',
                type: mongoose.Schema.Types.ObjectId
            },
            book: {
                ref: 'Book',
                type: mongoose.Schema.Types.ObjectId
            },
            paired: {
                ref: 'Transaction',
                type: mongoose.Schema.Types.ObjectId,
                default: null
            },
            additionalMaterial: Boolean,
            bookStatus: String,
            messages: [{
                    ref: 'Message',
                    type: mongoose.Schema.Types.ObjectId
                }]
        });
    }
}
exports.TransactionSchema = TransactionSchema;
// tslint:disable-next-line:variable-name
exports.Transaction = mongoose.model('Transaction', new TransactionSchema());

//# sourceMappingURL=transaction.model.js.map
