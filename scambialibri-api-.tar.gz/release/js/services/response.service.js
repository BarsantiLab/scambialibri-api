"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const config_1 = require("core/config");
const error_codes_1 = require("core/error-codes");
const log_1 = require("core/log");
let ResponseService = class ResponseService {
    constructor(_logger, _config) {
        this._logger = _logger;
        this._config = _config;
    }
    errorMiddleware(err, req, res, next) {
        let status = 500;
        let responseBody;
        if (err instanceof error_codes_1.ApiError) {
            responseBody = {
                code: err.errorCodeObject.code,
                message: err.errorCodeObject.message,
                stack: err.stack
            };
            if (err.data) {
                responseBody.data = err.data;
            }
            status = err.errorCodeObject.status;
        }
        else if (err instanceof Error) {
            responseBody = {
                message: err.message,
                stack: err.stack
            };
        }
        else {
            responseBody = {
                message: err
            };
        }
        switch (status) {
            case 400: return this.badRequest(responseBody, req, res, next);
            case 401: return this.unauthorized(responseBody, req, res, next);
            case 403: return this.forbidden(responseBody, req, res, next);
            case 404: return this.notFount(responseBody, req, res, next);
            default: return this.serverError(responseBody, req, res, next);
        }
    }
    serverError(err, req, res, next) {
        if (!this._config.debug.sendErrorsToClient) {
            return res.status(500).send();
        }
        res.status(500).send({
            code: err.code,
            data: err.data,
            message: err.message,
            stack: this._config.debug.sendStackToClient ? err.stack : undefined,
        });
        this._logger.error(err);
        process.exit(1);
    }
    badRequest(err, req, res, next) {
        res.status(400).send({
            code: err.code,
            data: err.data,
            message: err.message,
            stack: this._config.debug.sendStackToClient ? err.stack : undefined
        });
    }
    forbidden(err, req, res, next) {
        res.status(403).send({
            code: err.code,
            data: err.data,
            message: err.message,
            stack: this._config.debug.sendStackToClient ? err.stack : undefined
        });
    }
    unauthorized(err, req, res, next) {
        res.status(401).send({
            code: err.code,
            data: err.data,
            message: err.message,
            stack: this._config.debug.sendStackToClient ? err.stack : undefined
        });
    }
    notFount(err, req, res, next) {
        res.status(404).send({
            code: err.code,
            data: err.data,
            message: err.message,
            stack: this._config.debug.sendStackToClient ? err.stack : undefined
        });
    }
};
ResponseService = __decorate([
    inversify_1.injectable(),
    __metadata("design:paramtypes", [log_1.Logger,
        config_1.Configuration])
], ResponseService);
exports.ResponseService = ResponseService;

//# sourceMappingURL=response.service.js.map
