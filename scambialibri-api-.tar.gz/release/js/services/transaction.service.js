"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const transaction_interface_1 = require("interfaces/transaction.interface");
const message_model_1 = require("models/message.model");
const transaction_model_1 = require("models/transaction.model");
let TransactionService = class TransactionService {
    pairTransactions(trans1, trans2) {
        return __awaiter(this, void 0, void 0, function* () {
            yield transaction_model_1.Transaction.findByIdAndUpdate(trans1._id, {
                paired: trans2._id,
                status: transaction_interface_1.TransactionStatus.pending
            });
            yield transaction_model_1.Transaction.findByIdAndUpdate(trans2._id, {
                paired: trans1._id,
                status: transaction_interface_1.TransactionStatus.pending
            });
            // TODO: send mails
        });
    }
    sendMessage(transaction, content) {
        return __awaiter(this, void 0, void 0, function* () {
            const paired = yield transaction_model_1.Transaction.findById(transaction.paired);
            const msg = new message_model_1.Message({
                from: transaction.buyer || transaction.seller,
                to: paired.buyer || paired.seller,
                content,
                date: new Date()
            });
            yield transaction_model_1.Transaction.update({
                _id: {
                    $in: [transaction._id, paired._id]
                }
            }, {
                messages: {
                    $push: msg._id
                }
            });
            // TODO: send mails
        });
    }
};
TransactionService = __decorate([
    inversify_1.injectable()
], TransactionService);
exports.TransactionService = TransactionService;

//# sourceMappingURL=transaction.service.js.map
