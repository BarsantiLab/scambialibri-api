"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const lodash_1 = require("lodash");
function handleRejections(err, log) {
    const errors = [err];
    if (err.stack)
        errors.push(err.stack);
    if (err.name === 'ValidationError') {
        console.log(err.name + ': ' + err._message);
        lodash_1.forIn(err.errors, (v, k) => {
            console.log('    ' + k + ': ' + v.message);
        });
    }
    else {
        printErrors(errors, log);
    }
    process.exit(1);
}
exports.handleRejections = handleRejections;
function printErrors(errors, log) {
    errors.forEach(err => {
        log.error(err);
    });
}
exports.printErrors = printErrors;

//# sourceMappingURL=error-handling.js.map
