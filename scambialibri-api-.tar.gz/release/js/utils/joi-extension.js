"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const JoiPristine = require("joi");
const _ = require("lodash");
const mongoose = require("mongoose");
const error_codes_1 = require("core/error-codes");
// tslint:disable-next-line:variable-name
exports.Joi = JoiPristine.extend(joi => ({
    base: joi.string(),
    language: {
        objectId: 'needs to be an ObjectId instance'
    },
    name: 'string',
    rules: [{
            name: 'objectId',
            validate(params, value, state, options) {
                if (!mongoose.Types.ObjectId.isValid(value)) {
                    return this.createError('string.objectId', {
                        v: value
                    }, state, options);
                }
                return value;
            }
        }, {
            name: 'bookMode',
            validate(params, value, state, options) {
                if (value !== 'sell' && value !== 'buy') {
                    this.createError('string.bookMode', {
                        v: value
                    }, state, options);
                }
                return value;
            }
        }, {
            name: 'bookStatus',
            validate(params, value, state, options) {
                if (['new', 'pencilNotes', 'penNoted', 'badConditions'].indexOf(value) === -1) {
                    this.createError('string.bookStatus', {
                        v: value
                    }, state, options);
                }
                return value;
            }
        }]
}));
/**
 * Valida gli oggetti prendendo in input uno schema di Joi. Se la validazione passa chiama la callback, altrimenti lancia un errore di validazione
 *
 * @export
 * @param {(IValidationStep|IValidationStep[])} steps Step di validazione. Può essere un singolo oggetto ValidationStep oppure un array.
 * @param {any} [callback] Callback opzionale chiamata al successo della validazione
 */
function validate(steps, callback) {
    if (!_.isArray(steps))
        steps = [steps];
    let errors = [];
    steps.forEach((step) => {
        const result = exports.Joi.validate(step.object, step.schema, {
            abortEarly: false
        });
        if (result.error) {
            errors = [...errors, ...result.error.details.map(err => ({
                    label: err.context.label,
                    type: err.type
                }))];
        }
    });
    if (errors.length > 0) {
        throw new error_codes_1.ApiError(error_codes_1.ErrorCode.ValidationError, errors);
    }
    if (callback)
        callback();
}
exports.validate = validate;

//# sourceMappingURL=joi-extension.js.map
