"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const mk = require("mkdirp");
const rm = require("rimraf");
const util_1 = require("util");
exports.readdir = util_1.promisify(fs.readdir);
exports.rename = util_1.promisify(fs.rename);
exports.mkdirp = util_1.promisify(mk);
exports.rimraf = util_1.promisify(rm);
exports.createWriteStream = fs.createWriteStream;
exports.readFile = (path) => {
    return new Promise((resolve, reject) => {
        fs.readFile(path, 'utf8', (err, data) => {
            if (err)
                return reject(err);
            resolve(data);
        });
    });
};
exports.checkExist = (path) => {
    return new Promise((resolve, reject) => {
        fs.existsSync(path) ? resolve() : reject();
    });
};

//# sourceMappingURL=promise-fs.js.map
