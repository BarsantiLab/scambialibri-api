"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("core/config");
const inversify_1 = require("core/inversify");
const api_1 = require("api/api");
const db_1 = require("core/db");
function init_e2e() {
    return __awaiter(this, void 0, void 0, function* () {
        const conf = new config_1.Configuration();
        conf.mongo = conf.test.mongo;
        const backendConfig = inversify_1.InversifyContainer.get(config_1.Configuration);
        backendConfig.setConfiguration(conf);
        const server = inversify_1.InversifyContainer.get(api_1.Api);
        yield server.setup();
        yield server.listen();
        return {
            api: server,
            db: inversify_1.InversifyContainer.get(db_1.Db),
            url: `http://localhost:${backendConfig.http.port}/`
        };
    });
}
exports.init_e2e = init_e2e;

//# sourceMappingURL=test.js.map
